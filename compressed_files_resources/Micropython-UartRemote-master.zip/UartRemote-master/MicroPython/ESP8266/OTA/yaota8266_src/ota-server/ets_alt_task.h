extern int ets_loop_iter_disable;
extern uint32_t system_time_high_word;

bool ets_loop_iter(void);

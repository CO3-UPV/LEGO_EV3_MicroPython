# UartRemote library for Arduino

The documentation for this Arduino UartRemote library can be found on  [UartRemote.readthedocs.io](https://uartremote.readthedocs.io/en/latest/arduinouartremote.html).

## Arduino and Platform IO 

In Platform IO you need to include ``#include <Arduino.h>``, whereas in Arduino IDE you have to ommit this include statement.


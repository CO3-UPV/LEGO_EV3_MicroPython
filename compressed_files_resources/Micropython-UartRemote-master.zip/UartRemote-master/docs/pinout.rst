.. currentmodule:: pinout
.. _pinout:

LMS ESP32 Pinout
============================

.. image:: ./images/lms_esp32_pinout.jpg
  :alt: LMS_esp32 Pinout

The graph above shows the pinout of the LMS ESP32 expansion board. All ESP32 GPIO pins are indicated. Where they have a specific functions, that is idicated by an extra pin label.